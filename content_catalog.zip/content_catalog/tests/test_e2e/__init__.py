"""
End-to-end tests for Content Catalog system.

This package contains integration tests that verify complete user flows
across multiple API endpoints, simulating real-world usage scenarios.
"""
