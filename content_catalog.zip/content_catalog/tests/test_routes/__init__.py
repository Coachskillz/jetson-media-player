"""Test routes package for Content Catalog API endpoint tests."""
